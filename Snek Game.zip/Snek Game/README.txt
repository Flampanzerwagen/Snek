Why hello there, traveller

If you are reading this, then you have acquired a copy of this gucci-ass game, Snek.

If you wanna mod it, mkake sure the folder which contains the "game.exe file also contains a "data" folder with a "highscore.txt" file and two audio files:
"knightmare.wav" and "sound.wav". The audio formats, file names and folder locations must be as stated.

"knightmare.wav" is the background music and "sound.wav" is the sound effect of the snake eating a fruit.

Also make sure that "highscore.txt" contains a single number, no spaces and no extra lines.