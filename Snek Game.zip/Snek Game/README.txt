Why hello there, traveller

If you are reading this, then you have acquired the greatest game of all time - Snek, made by me.

This game was originally made using python's Pygame module, and then converted to an executable using "cx-Freeze".

Make sure the folder which contains the game file also contains a "data" folder with a "highscore.txt" file and two audio files:
"knightmare.wav" and "sound.wav". The audio formats, file names and folder locations must be as stated.

"knightmare.wav" will be the background music and "sound.wav" will be the sound effect of the snake when it eats a fruit.

Also make sure that highscore.txt contains a single number, no spaces and no extra lines.

Fedya Cheltsov